#include <iostream>

using namespace std;

int main()
{
    bool m;
    m = true;
    while ( m == true )
        {
        float x;
        float s = 0;
        float c = 1;
        cout << "Enter the number: ";
        cin >> x;
        cout << endl;
        if (x == 0)
            {
            cout << "The Square root equals : 0";
            m = false;
            }
        else if (x > 0)
            {
            while (abs (s - c) > 0.000001) {
                s = c;
                c  = 0.5*(c + x / c);
                m = false;
                }
            cout << endl << "The calculated square root is: " << s << endl;
            }
        else if (x < 0)
            {
            cout << "Wrong input because it's a negative number please enter a positive number : ";
            cin >> x;
            cout << endl;
            }
        }
    return 0;
}
